//
//  ViewController.swift
//  PermisoInternet
//
//  Created by Romina Pozzuto on 13/01/2020.
//  Copyright © 2020 Romina Pozzuto. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var search: UISearchBar!

    @IBOutlet weak var textView: UITextView!

    @IBOutlet weak var labelTitulo: UILabel!

    @IBOutlet weak var labelAutores: UILabel!

    @IBOutlet weak var portada: UIImageView!
    
    
    let urlinicial = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:"
    var url = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.search.delegate = self
        let gesture = UITapGestureRecognizer(target: self, action: #selector(closeKeyboardType(_:)))
        self.view.addGestureRecognizer(gesture)
    }
    
    
    
    func verDatosLibro (urls:String, isbn:String) {
        let url = URL(string: urls)
        let datos:NSData? = NSData(contentsOf: url! as URL)
        
        if datos == nil {
            self.textView.text = "¡Algo salió mal :| ! intenta nuevamente en unos minutos"
            self.textView.isHidden = false
            self.labelAutores.isHidden = true
            self.labelTitulo.isHidden = true

        }
        else {
            let texto = NSString(data: datos! as Data, encoding: String.Encoding.utf8.rawValue)
            textView.text = String(texto!)
            if texto == "{}" {
                self.textView.text = "El número de ISBN ingresado no se encuentra en nuestros registros"
                self.textView.isHidden = false
                self.labelAutores.isHidden = true
                self.labelTitulo.isHidden = true

                
            }
            else {
                do {
                    let json = try JSONSerialization.jsonObject(with: datos! as Data, options: JSONSerialization.ReadingOptions.mutableLeaves)
                    let dico1 = json as! NSDictionary
                    let dico2 = dico1[isbn] as! NSDictionary
                    
                    let nameTitle = dico2["title"] as! NSString as String
                    self.labelTitulo.text = "Título del libro: \(nameTitle)"
                    
                    let autor = dico2["authors"] as! NSArray
                    self.showNamesAuthors (autor: autor)
                    if dico2["cover"] != nil {
                    let dico3 = dico2["cover"] as! NSDictionary
                    let Imagen = dico3["small"] as! NSString as String
                    let urlImagen = URL(string: Imagen)!
                    let imagendata :NSData = try NSData(contentsOf: urlImagen)
                    let imagen = UIImage (data: imagendata as Data)
                    self.portada.image = imagen
                    }
                }
                catch _ {
                    
                }
            }
        }
    }
    
    func showNamesAuthors (autor: NSArray) {
        let total = autor.count
        var nombreAutor = ""
        var i = 0
        while i < total {
            let dico3 = autor[i] as! NSDictionary
            nombreAutor = nombreAutor + (dico3["name"] as! NSString as String) + ", "
            i = i + 1
        }
        self.labelAutores.text = "Autor/es: \(nombreAutor)"
    }
    
    
    //agregar esta función en el didLoad en el caso de querer ver el JSON.
    //Para esta versión no se usa, por eso el textView está oculto.
    func showJson() {
        if self.search.text == "" {
            self.textView.text = "Aquí verás el JSON del libro buscado por ISBN"
        }
    }

}

extension ViewController: UISearchBarDelegate{

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        var dir: String = ""
        var dir2: String = ""
        var bn: String = ""
        dir2 = String (search.text!)
        bn = "ISBN:" + String (search.text!)
        dir = urlinicial + dir2
        self.verDatosLibro (urls: dir, isbn: bn)

    }
    
    @objc func closeKeyboardType(_ sender: UITapGestureRecognizer) {
            self.view.endEditing(true)
        }
}
